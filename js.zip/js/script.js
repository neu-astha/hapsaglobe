
var swiper = new Swiper(".home__projects", {
    slidesPerView: 3,
    spaceBetween: 40,
    navigation: {
      nextEl: ".home__projectsnav.swiper-button-next",
      prevEl: ".home__projectsnav.swiper-button-prev",
    },
  });

const video = document.getElementById("myVideo");
const muteButton = document.getElementById("muteButton");

muteButton.addEventListener("click", function () {
    video.muted = !video.muted;
    muteButton.textContent = video.muted ? "Unmute" : "Mute";
    muteButton.classList.toggle("muted", video.muted);
    muteButton.classList.toggle("unmuted", !video.muted);
});
  